/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 011                                                   *//
//* Description: Ship Class                                             *//
//* Date: 13/12/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//start Class
public class Ship {
	
	//Instantiates objects
	public int shipSize;
	private int shipStartLoc;
	private int shipPose;
	
	//Method to instantiate ship objects
	public Ship(int shipSize, int shipStartLoc, int shipPose) {
		this.shipSize = shipSize;
		this.shipStartLoc = shipStartLoc;
		this.shipPose = shipPose;
	}//end Method
	
	//Method to call Ship object value
	public Ship() {
		this.shipSize = -1;
		this.shipStartLoc = -1;
		this.shipPose = -1;
	}//end Method
	
	//Method to get size of ship
	public int getShipSize() {
		return shipSize;
	}//end Method
	
	//Method to get ship starting location
	public int getShipStartLoc() {
		return shipStartLoc;
	}//end Method
	
	//Method to get ship position
	public int getShipPose() {
		return shipPose;
	}//end Method
	
	//Method to set size of ship
	public void setShipSize(int shipSize) {
		this.shipSize = shipSize;
	}//end Method
	
	//Method to set ship starting location
	public void setShipStartLoc(int shipStartLoc) {
		this.shipStartLoc = shipStartLoc;
	}//end Method
	
	//Method to set ship position
	public void setShipPose(int shipPose) {
		this.shipPose = shipPose;
	}//end Method
	
}//end Class
