/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 011                                                   *//
//* Description: BattleShipGame Class                                   *//
//* Date: 13/12/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import java packages
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

//start Class
public class BattleShipGame {
	
	//Set up variables and constraints
	public static Ship[] ship = new Ship[6];
	public static int[] tileOccupied = new int[100];
	public static int shipHit = 0;
	public static boolean endGame = false;
	
	//Constructor Method for game
	public BattleShipGame() {
			
		//Set up board
		//Set up arrays to hold data
		//Sets up every tile as empty to start
		for (int i=0; i < 100; i++) {
			tileOccupied[i] = 0;
		}//end For statement
				
		//Place ships on board
		for (int i=0; i < 6; i++) {
			//If boat is horizontal
			//Put a 1 in all that line
			if (ship [i].getShipPose() == 0) {
				for (int j = ship[i].getShipStartLoc(); j < (ship[i].getShipStartLoc() + ship[i].getShipSize()); j++) {
					//Marks the tile as a ship tile
					tileOccupied [j] = 1;
				}
			}
				
			//If the boat is vertical
			//Put a 1 in that column
			if (ship [i].getShipPose() == 1) {
				for (int j = ship[i].getShipStartLoc(); j < ship[i].getShipStartLoc() + (ship[i].getShipSize() * 10); j += 10) {
					//Marks the tile as a ship tile
					tileOccupied [j] = 1;
				}//end For statement
			}//end If statement
		}//end For Statement
	}//end Constructor
	
	//Method to detect if ship was hit
	public static void WasShipHit() {
		//adds 1 to shipHit.
		shipHit = shipHit + 1;
		//If shipHit is greater than or equal to 16 (Max ship parts)
		if(shipHit >= 16) {
			//Display a message saying the player won
			JOptionPane.showMessageDialog(null, "All ships have been sunk, you won!");
			//Closes the program
			System.exit(0);
			endGame = true;
		}//end If statement
	}//end Method
	
	
	//Method to set up ships
	private static void shipSetup() {
		//Set up ships
		//0 is horizontal
		//1 is vertical
		
		//ship = (size, starting location, position)
		ship[0] = new Ship(4, 23, 0);	
		ship[1] = new Ship (3, 41, 1);
		ship[2] = new Ship (3, 56, 0);
		ship[3] = new Ship (2, 10, 0);
		ship[4] = new Ship (2, 63, 1);
		ship[5] = new Ship (2, 86, 0);
	}//end Method
		
	//Method Main to run game
	public static void main(String[] args) {
		
		//integer for menu input
		int menuInput;
		//Do while, ask player if they want to start a game or not
		do {
			//Start or Exit game
			String input = JOptionPane.showInputDialog("Menu: Choose an Option" + "\n1. Start Game" + "\n2. Exit Game");
			//Input from InputDialog = menuInput integer
			menuInput = Integer.parseInt(input);
		} while (!isValid(menuInput)); {
			//While menuInput checks isValid
			//If menuInput = 1, start the game
			if (menuInput == 1) {
				//Set up ships
				shipSetup();
				//Instantiates battle ship game	
				BattleShipGame myGame = new BattleShipGame();
				
				//Creates rows and columns in 10
				int rows = 10;
				int cols = 10;
				
				//Creates a new board
				Board gameBoard = new Board(rows, cols);
				gameBoard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				gameBoard.pack();
				gameBoard.setVisible(true);
			}
			//Else if menuInput = 2, exit the game
			else if (menuInput == 2) {
				//End the game
				endGame = true;
				//Thanks for playing
				JOptionPane.showMessageDialog(null, "Thanks for playing!");
			}//end If statement
		}//end Do while loop		
	}//end Method
	
	//Method to check if input is valid
	private static boolean isValid(int menuInput) {
		//If menuInput is greater than 2
		//Or less than 1
		if(menuInput > 2 || menuInput < 1) {
			//Print out an error
			JOptionPane.showMessageDialog(null, "Error! You've entered an invalid answer");
			//Return false and restart question
			return false;
		} else return true;
		//end If statement
	}//end Method
	
}//end Class
