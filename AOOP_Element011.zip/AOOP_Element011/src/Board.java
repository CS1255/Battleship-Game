/*************************************************************************/
//* Name: SID: 1801710                                                  *//
//* Task: Element 011                                                   *//
//* Description: Board Class                                   			*//
//* Date: 13/12/2020                                                    *//
//*                                                                     *//
/************************************************************************/

//import java packages
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

//start Class
//Extends JFrame and Implements ActionListener
public class Board extends JFrame implements ActionListener {
	//Instantiates objects
	public static JButton[] boardTile = new JButton[100];
	public static int ammoCount = 50;
	
	//Method to set up board and buttons
	public Board(int rows, int cols) {
		//Prints line of total Ammo Count
		System.out.println("Ammo Count: " + ammoCount);
		
		//Context in a pane
		Container pane = getContentPane();
		pane.setLayout(new GridLayout(rows, cols, 0, 0));
		
		//Creates a new tile until there are 100
		for (int i = 0; i < 100; i++) {	
			//Is a JButton
			//No text
			//Board tile info: 50, 50 size.
			boardTile[i] = new JButton("");
			boardTile[i].setPreferredSize(new Dimension(50, 50));
			boardTile[i].addActionListener(this);
			boardTile[i].setActionCommand(Integer.toString(i));
			//Sets board colour to white
			Board.boardTile[i].setBackground(Color.WHITE);
			Board.boardTile[i].setOpaque(true);
			//Adds boardTile to pane
			pane.add(boardTile[i]);
		}//end For statement
	}//end Method
	
	
	//Method to check if boardTiles have been clicked.
	public void actionPerformed(ActionEvent e) {
		//Board number amount of tiles, i.e. count from 1 to 100.
		int boardNumber = Integer.parseInt(e.getActionCommand());
		
		//Text appears when a tile is pressed.
		Board.boardTile[boardNumber].setText("X");
		
		//While loop for when ammoCount
		//is greater than 0
		while(ammoCount > 0) {
			//If the tile is a ship part
			if (BattleShipGame.tileOccupied [boardNumber] == 1) {
				//Colour tile as red
				Board.boardTile[boardNumber].setBackground(Color.RED);
				//Print out that player hit a ship
				System.out.println("You hit a ship!");
				//Reduce ammoCount by 1
				ammoCount = ammoCount - 1;
				//Print updated ammo count
				System.out.println("Ammo Count: " + ammoCount);
				//Call method to see if all ships have been sunk
				BattleShipGame.WasShipHit();
				//end loop
				break;
				
			} else {
				//Else if player misses
				//Colour tile as blue
				Board.boardTile[boardNumber].setBackground(Color.BLUE);
				//Print out that player missed
				System.out.println("You missed!");
				//Reduce ammoCount by 1
				ammoCount = ammoCount - 1;
				//Print out updated ammo count
				System.out.println("Ammo Count: " + ammoCount);
				//end loop
				break;	
			}//end If statement	
		}//end While loop
			
		//If ammo count has reached 0
		if(ammoCount == 0) {
			//Show message dialog that the player lost
			JOptionPane.showMessageDialog(null, "You ran out of ammo, you've lost.");
			//Close the game
			System.exit(0);
		}//end If statement
		
		//If true, set as opaque
		//Else if false, set as enabled
		Board.boardTile[boardNumber].setOpaque(true);
		Board.boardTile[boardNumber].setEnabled(false);
		
	}//end Method

}//end Class
